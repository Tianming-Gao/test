#!/bin/bash
set -ex
umask 022
filename=$(date "+%y%m%d%H%M%S").tar.gz
bakdir="/var/lib/hotdir"
cd /var/lib
if [ ! -d "/var/lib/hotbak" ]; then
	mkdir hotbak
fi
tar -zcvf /var/lib/hotbak/$filename usvn
find /var/lib/hotbak -mmin +180 -name *.tar.gz -exec rm {} \;
