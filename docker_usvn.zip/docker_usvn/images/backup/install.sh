chmod a+x /tmp/*.sh
mv /tmp/daily-backup.sh /usr/local/bin
mv /tmp/hourly-backup.sh /usr/local/bin
mv /tmp/crontab /etc/cron.d
