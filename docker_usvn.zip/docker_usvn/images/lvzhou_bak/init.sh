#!/bin/sh
REPNAME=lvzhou_game
BAKPATH=/data00/lvzhou_bak
SRCPATH=/data00/svn
HOOKS=$BAKPATH/$REPNAME/hooks

mkdir -p $BAKPATH/$REPNAME
svnadmin create $BAKPATH/$REPNAME

echo \#\!/bin/sh > $HOOKS/pre-revprop-change
echo exit 0 >> $HOOKS/pre-revprop-change

chmod +x $HOOKS/pre-revprop-change

cp -r $SRCPATH/$REPNAME/conf $BAKPATH/$REPNAME/

svnsync init file://$BAKPATH/$REPNAME file://$SRCPATH/$REPNAME

svnsync synchronize file://$BAKPATH/$REPNAME
touch $HOOKS/existFlagFile
