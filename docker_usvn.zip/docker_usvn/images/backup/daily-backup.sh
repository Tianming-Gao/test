#!/bin/bash
set -ex
umask 022
filename=$(date "+%y%m%d").tar.gz
cd /var/lib
if [ ! -d "/var/lib/coldbak" ]; then
	mkdir coldbak
fi
tar -zcvf /var/lib/coldbak/$filename usvn
find $bakdir -mtime +3 -name *.tar.gz -exec rm {} \;
