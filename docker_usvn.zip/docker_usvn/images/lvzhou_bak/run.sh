#!/bin/bash
svnsync synchronize file:///data00/lvzhou_bak/lvzhou_game
