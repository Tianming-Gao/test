<?php
/**
 * Usefull methods for project management
 *
 * @author Team USVN <contact@usvn.info>
 * @link http://www.usvn.info
 * @license http://www.cecill.info/licences/Licence_CeCILL_V2-en.txt CeCILL V2
 * @copyright Copyright 2007, Team USVN
 * @since 0.6
 * @package usvn
 * @subpackage Table
 *
 * This software has been written at EPITECH <http://www.epitech.net>
 * EPITECH, European Institute of Technology, Paris - FRANCE -
 * This project has been realised as part of
 * end of studies project.
 *
 * $Id$
 */
class USVN_Project
{
	/**
	 * Create SVN repositories
	 *
	 * @param string Project name
	 * @param bool Create standard directories (/trunk, /tags, /branches)
	 */
	static private function createProjectSVN($project_name, $create_dir)
	{

		$config = Zend_Registry::get('config');
		//lvzhou_game目录
		$path = $config->subversion->path;
		if (!USVN_SVNUtils::isSVNRepository($path, true)) {
			$directories = explode(DIRECTORY_SEPARATOR, $path);
			$tmp_path = '';
			foreach ($directories as $directory) {
				$tmp_path .= $directory . DIRECTORY_SEPARATOR;
				if (USVN_SVNUtils::isSVNRepository($tmp_path)) {
					$tmp_path = '';
					break;
				}
			}
			if ($tmp_path === $path . DIRECTORY_SEPARATOR) {
				if ($mod = $config->subversion->chmod) {
					$mod = intval($mod, 8);
				} else {
					$mod = 0700;
				}
				@mkdir($path, $mod, true);
				@chmod($path, $mod); // mkdir is bogus

				USVN_SVNUtils::createSVN($path);

				if ($create_dir) {
					USVN_SVNUtils::createStandardDirectories($path);
				}

				// apply files rights
				$iterator = new RecursiveIteratorIterator(
					new RecursiveDirectoryIterator($path, FilesystemIterator::SKIP_DOTS),
					RecursiveIteratorIterator::CHILD_FIRST
				);
				foreach ($iterator as $file) {
					@chmod((string) $file, $mod);
				}


				// apply special dir rights on repo/db
				if ($mod = $config->subversion->chmod_db) {
					$mod = intval($mod, 8);
					$dbPath = $path.'/db';
					@chmod($dbPath, $mod);

					$iterator = new RecursiveIteratorIterator(
						new RecursiveDirectoryIterator($dbPath, FilesystemIterator::SKIP_DOTS),
						RecursiveIteratorIterator::CHILD_FIRST
					);
					foreach ($iterator as $file) {
						if ($file->isDir()) {
							@chmod((string) $file, $mod);
						}
					}
				}

			} else {
				$message = "One of these repository's subfolders is a subversion repository.";
				throw new USVN_Exception(T_("Can't create subversion repository:<br />%s"), $message);
			}
		} else {
			USVN_SVNUtils::createSVN($path);
			//$message = $project_name." is a SVN repository.";
			//throw new USVN_Exception(T_("Can't create subversion repository:<br />%s"), $message);
		}
	}

	static private function ApplyFileRights($project, $group, $create_svn_directories)
	{
		$acces_rights = new USVN_FilesAccessRights($project->projects_id);

		$acces_rights->setRightByPath($group->groups_id, '/', true, false);
		$acces_rights->setRightByPath($group->groups_id, '/'.$project->projects_name, true, false,true);
	}

	/**
	 * Create a project
	 *
	 * @param array Fields data
	 * @param string The creating user
	 * @param bool Create a group for the project
	 * @param bool Add user into group
	 * @param bool Add user as admin for the project
	 * @param bool Create SVN standard directories
	 * @return USVN_Db_Table_Row_Project
	 */
	static public function createProject(array $data, $login, $create_group, $add_user_to_group, $create_admin, $create_svn_directories)
	{
		//We need check if admin exist before create project because we can't go back
        $create_svn_directories = null;
		$user_table = new USVN_Db_Table_Users();
		$user = $user_table->fetchRow(array('users_login = ?' => $login));
		if ($user === null) {
			throw new USVN_Exception(T_('Login %s not found'), $login);
		}

		$groups = new USVN_Db_Table_Groups();
		if ($create_group) {
			$group = $groups->fetchRow(array('groups_name = ?' => $data['projects_name']));
			if ($group !== null) {
				throw new USVN_Exception(T_("Group %s already exists."), $data['projects_name']);
			}
		}
		try {
			$table = new USVN_Db_Table_Projects();
			$table->getAdapter()->beginTransaction();
			$project = $table->createRow($data);
			$project->save();

			//USVN_Project::createProjectSVN($data['projects_name'], $create_svn_directories);

			$config = Zend_Registry::get('config');
			//lvzhou_game目录
			$path = $config->subversion->path;
			//拿到lvzhou_game的二级目录列表，用array保存起来
			//判断传入的项目名（目录）是否在array里
			//不在  异常
			//在 得到路径名，加入到列表，显示到前端
			//$escape_path = USVN_SVNUtils::getRepositoryPath($repository . '/' . $path);
			//$lists = USVN_ConsoleUtils::runCmdCaptureMessageUnsafe(USVN_SVNUtils::svnCommand("ls --xml $escape_path"), $return);

			//if ($return) {
			//	throw new USVN_Exception(T_("Can't list subversion repository: %s"), $lists);
			//}

			//lvzhou_game 目录下的所有文件，$lvzhou_game[0]['name'];
			$lvzhou_games = USVN_SVNUtils::listSvn($path,'/');
			$flag = true;
			foreach ($lvzhou_games as $lvzhou_game) {
				if($lvzhou_game['name'] === $data['projects_name']){
					$flag = false;
					break;	
				}
			}
			if($flag) {
				throw new USVN_Exception(T_("not exist."));
			}

			if ($create_group) {
				$group = $groups->createRow();
				$group->description = sprintf(T_("Autocreated group for project %s"), $data['projects_name']);
				$group->name = $data['projects_name'];
				$group->save();

				$project->addGroup($group);

				USVN_Project::ApplyFileRights($project, $group, $create_svn_directories);
			}

			if ($create_group && $add_user_to_group) {
				$group->addUser($user);
				$group->promoteUser($user);
			}
			if ($create_admin) {
				$project->addUser($user);
			}
		}
		catch (Exception $e) {
			$table->getAdapter()->rollBack();
			throw $e;
		}
		$table->getAdapter()->commit();
		return $project;
	}

	public static function deleteProject($project_name)
	{
		$table = new USVN_Db_Table_Projects();
		$project = $table->fetchRow(array('projects_name = ?' => $project_name));
		if ($project === null) {
			throw new USVN_Exception(T_("Project %s doesn't exist."), $project_name);
		}
		$project->delete();
		$groups = new USVN_Db_Table_Groups();
		$where = $groups->getAdapter()->quoteInto("groups_name = ?", $project_name);
		$group = $groups->fetchRow($where);
		if ($group !== null) {
			$group->delete();
		}

/*		USVN_DirectoryUtils::removeDirectory(Zend_Registry::get('config')->subversion->path
		. DIRECTORY_SEPARATOR
		. 'svn'
		. DIRECTORY_SEPARATOR
		. $project_name);

 */
	}
}
