set -ex
umask 022
cat > /etc/apt/sources.list <<EOF
deb http://mirrors.byted.org/debian stretch main contrib non-free
deb http://mirrors.byted.org/debian stretch-backports main contrib non-free
deb http://mirrors.byted.org/debian-security stretch/updates main contrib non-free
EOF
apt-get update
apt-get install -y subversion libapache2-mod-svn sqlite3
a2enmod rewrite

rm -rf /var/www/html
ln -s /var/lib/usvn/src/public /var/www/html
chown -R www-data:www-data /var/lib/usvn/src/public
chown -R www-data:www-data /var/lib/usvn/src/config
chown -R www-data:www-data /var/lib/usvn/src/files

