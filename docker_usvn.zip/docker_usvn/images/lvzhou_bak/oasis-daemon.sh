#!/bin/bash

file="/data00/lvzhou_bak/lvzhou_game/hooks/existFlagFile"
if [ ! -f "$file" ];then
	/usr/local/bin/init.sh
fi

while true
do
	trap "/usr/local/bin/run.sh" 10
	sleep 1
done
